<?php
return array(
	'cron_pick' => array('autopick', 1800),
	'cron_dataarea_update' => array('dataarea_update', 1800)
);