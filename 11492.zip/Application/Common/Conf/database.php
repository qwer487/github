<?php
return array(
	'DB_TYPE'	=>  'mysql',
	'DB_HOST'	=>  'localhost',
	'DB_NAME'	=>  'cehsi',
	'DB_USER'	=>  'cehsi',
	'DB_PWD'	=>  'Na3YBYsXtNyK7MaL',
	'DB_PORT'	=>  '3306',
	'DB_PREFIX'	=>  'book_'
);