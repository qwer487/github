<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<meta http-equiv="Cache-Control" content="no-transform" />
	<title><?php echo ($TDK["title"]); ?></title>
	<meta name="keywords" content="<?php echo ($TDK["keyword"]); ?>" />
	<meta name="description" content="<?php echo ($TDK["description"]); ?>" />
	<link rel="canonical" href="<?php echo ($TDK["weburl"]); ?>"/>
	<meta name="applicable-device" content="pc">
	<meta http-equiv="mobile-agent" content="format=html5; url=<?php echo ($TDK["canonicalurl_m"]); ?>">
	<link rel="stylesheet" href="/Public/<?php echo ($theme); ?>/css/style.css?v<?php echo ($version); ?>" />
	<link rel="stylesheet" href="/Public/<?php echo ($theme); ?>/css/c/zzsc.css" />
	<link rel="stylesheet" href="//at.alicdn.com/t/font_626180_rzkibgk7ogl.css">
</head>
<body>
<div id="wrapper">
	<header class="header">
	<div class="header-div">
			<a class="pc-logo" href="/"><img src="/Public/<?php echo ($theme); ?>/images/logo.png" alt="<?php echo ($TDK["webname"]); ?>"></a>
		<?php if(is_array($category)): foreach($category as $key=>$vo): ?><a href="<?php echo ($vo['url']); ?>" <?php if($category[$key]['dir'] == $cate): ?>class="active"<?php endif; ?>><?php echo ($vo['name']); ?></a><?php endforeach; endif; ?>
		<span class="hide"></span>
		<span class="pc-login">
			<a class="register" href="<?php echo U('/home/index/bookcase');?>">书架</a>
			<a class="login" href="<?php echo ($catelist["top"]); ?>">排行<i class="iconfont icon-fs-line"></i></a>
		</span>
		<span class="header-search">
		<form action="<?php echo U('/home/search');?>" method="post">
		<input type="hidden" name="action" value="search">
		<input name="q" placeholder="输入书名/关键词" type="text" >
		<button> <i class="iconfont icon-search" type="submit" ></i></button>
		</form>
		</span>
	</div>
</header>

	<div id="main">
<!-- 小说第一板块 -->
	<div class="huan1">
<div id="gal">
	<nav class="galnav">
		<ul>
			<li>
				<input type="radio" name="btn" value="one" checked="checked" />
				<label for="btn"></label>
				<figure>
					<img src="<?php echo ($TDK["huandeng1"]); ?>" />
				</figure>
			</li>
			<li>
				<input type="radio" name="btn" value="two" />
				<label for="btn"></label>
				<figure class="entypo-forward">
					<img src="<?php echo ($TDK["huandeng2"]); ?>" />
				</figure>
			</li>
			<li>
				<input type="radio" name="btn" value="three" />
				<label for="btn"></label>
				<figure class="entypo-forward">
					<img src="<?php echo ($TDK["huandeng3"]); ?>" />
				</figure>
			</li>
			<li>
				<input type="radio" name="btn" value="four" />
				<label for="btn"></label>
				<figure class="entypo-forward">
					<img src="<?php echo ($TDK["huandeng4"]); ?>" />
				</figure>
			</li>
			<li>
				<input type="radio" name="btn" value="five" />
				<label for="btn"></label>
				<figure class="entypo-forward">
					<img src="<?php echo ($TDK["huandeng5"]); ?>" />
				</figure>
			</li>
		</ul>
	</nav>
</div>
<div class="focusInfo">
	<div class="focusInfoBox">
		<h3 class="newNotice">书城推荐</h3>
		<ul>
		<?php if(is_array($dataarea_list["pc_index_tuinilea"])): foreach($dataarea_list["pc_index_tuinilea"] as $key=>$v): ?><li><a class="name" href="<?php echo ($v["rewriteurl"]); ?>" target="_blank" title="《<?php echo ($v["title"]); ?>》"><?php echo ($v["title"]); ?></a></li><?php endforeach; endif; ?>
		</ul>
	</div>
</div>
</div>
<!-- 第一板块结束 -->
<?php echo ($advcode["index_1"]["code"]); ?>
<!-- 第二板块开始 -->
		<div id="hotcontent">
			<div class="l">
			<h3 class="lang">本周热门小说</h3>
				<?php if(is_array($dataarea_list["pc_index_fengtui"])): foreach($dataarea_list["pc_index_fengtui"] as $key=>$v): ?><div class="item">
					<div class="image">
						<a href="<?php echo ($v["rewriteurl"]); ?>" title="《<?php echo ($v["title"]); ?>》在线阅读"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>" width="72" height="96" onerror="this.src='/Public/images/nocover.jpg'" /></a>
					</div>
					<dl>
						<dt>
						 <a href="<?php echo ($v["rewriteurl"]); ?>"><?php echo ($v["title"]); ?></a>
						</dt>
						<dd><?php echo ($v["description"]); ?>...</dd>
						<div class="state-box cf">
						<i><?php echo ($v["catename"]); ?></i>
						<a class="author default"><img src="/Public/<?php echo ($theme); ?>/images/zuozhei.png"/><?php echo ($v["author"]); ?></a></div>
					</dl>
					<div class="clear"></div>
				</div><?php endforeach; endif; ?>
			</div>
			<div class="r">
			<h3 class="lang">好书榜</h3>
			
					<div class="s-index-side">
					
                <div class="part weekly game-top10 cls">
                  <ul class="weekly-list cls">
				<?php $k = '0'; ?>
				<?php if(is_array($dataarea_list["pc_index_jingdian"])): foreach($dataarea_list["pc_index_jingdian"] as $key=>$v): $k = $k+1; ?>
<li>
<div class="app-show-title"><span class="num s-index-org"><?php echo ($k); ?>.</span><a href="<?php echo ($v["rewriteurl"]); ?>" ><?php echo ($v["title"]); ?></a></div>
<div class="app-show-block">
<a href="<?php echo ($v["rewriteurl"]); ?>" class="pic"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>"  /><span class="mask mask2"></span></a>
<div class="s-index-star s-index-star-<?php echo ($k); ?>"><div class="s-index-star-big wrap"><span class="one">&nbsp;</span><span class="two">&nbsp;</span><span class="three">&nbsp;</span><span class="four">&nbsp;</span><span class="five">&nbsp;</span></div></div>
<a href="<?php echo ($v["rewriteurl"]); ?>"   class="event-exe-install s-index-down s-index-icon">阅&nbsp;读</a>
</div>
</li><?php endforeach; endif; ?>
                 </ul>
               </div>
            </div>
          </div>

			<div class="clear"></div>
		</div>
<!-- 小说第二板块结束 -->
<!-- 今日推荐小说 -->
<div class="free-book-wrap mb20" id="j-freeBookWrap">
	<div id="time-box" class="time-box fl" data-endtime="1561823999">
		<div class="limit-wrap">
			<h3 class="lang">今日小说推荐</h3>
			<p class="type">
				阅读热门小说
			</p>
			<div class="icon-time">
			</div>
			<p class="countdown" id="countdown">
			<?php echo (date('Y年m月d日',(isset($data["time"]) && ($data["time"] !== ""))?($data["time"]):time())); ?>
			</p>
			<a class="blue" href="/free" target="_blank"><?php echo ($TDK["webname"]); ?>排行榜<span>&gt;</span></a>
		</div>
	</div>
	<ul class="fl">
	<?php if(is_array($dataarea_list["pc_index_tuinile"])): foreach($dataarea_list["pc_index_tuinile"] as $key=>$v): ?><li>
		<div class="book-img">
			<a href="<?php echo ($v["rewriteurl"]); ?>" target="_blank"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" onerror="this.src='/Public/images/nocover.jpg'" alt="《<?php echo ($v["title"]); ?>》" /></a>
		</div>
		<a class="name" href="<?php echo ($v["rewriteurl"]); ?>" target="_blank"><?php echo ($v["title"]); ?></a>
		<p><?php echo ($v["author"]); ?></p>
		<a class="light-border-btn" href="<?php echo ($v["rewriteurl"]); ?>" target="_blank">阅读小说</a>
		</li><?php endforeach; endif; ?>
	</ul>
</div>
<?php echo ($advcode["index_2"]["code"]); ?>
<!-- 小说第三板块开始 -->
			<div id="hotcontent">

		  			<div class="t">
			<h3 class="lang">玄幻阅读<em class="icona icon-xuanhuan"></em></h3>
			
					<div class="s-index-side">
					
                <div class="part weekly game-top10 cls">
                  <ul class="weekly-list cls">
				<?php $k = '0'; ?>
				<?php if(is_array($dataarea_list["pc_index_xiuzhen"])): foreach($dataarea_list["pc_index_xiuzhen"] as $key=>$v): $k = $k+1; ?>
<li>
<div class="app-show-title"><span class="num s-index-org"><?php echo ($k); ?>.</span><a href="<?php echo ($v["rewriteurl"]); ?>" ><?php echo ($v["title"]); ?></a></div>
<div class="app-show-block">
<a href="<?php echo ($v["rewriteurl"]); ?>" class="pic"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>"  /><span class="mask mask2"></span></a>
<dd><?php echo ($v["description"]); ?></dd>
</div>
</li><?php endforeach; endif; ?>
                 </ul>
               </div>
            </div>
          </div>

		  			<div class="t">
			<h3 class="lang">网游阅读<em class="icona icon-chuanyeu"></em></h3>
			
					<div class="s-index-side">
					
                <div class="part weekly game-top10 cls">
                  <ul class="weekly-list cls">
				<?php $k = '0'; ?>
				<?php if(is_array($dataarea_list["pc_index_chuanyue"])): foreach($dataarea_list["pc_index_chuanyue"] as $key=>$v): $k = $k+1; ?>
<li>
<div class="app-show-title"><span class="num s-index-org"><?php echo ($k); ?>.</span><a href="<?php echo ($v["rewriteurl"]); ?>" ><?php echo ($v["title"]); ?></a></div>
<div class="app-show-block">
<a href="<?php echo ($v["rewriteurl"]); ?>" class="pic"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>"  /><span class="mask mask2"></span></a>
<dd><?php echo ($v["description"]); ?></dd>
</div>
</li><?php endforeach; endif; ?>
                 </ul>
               </div>
            </div>
          </div>

		  			<div class="t">
			<h3 class="lang">都市阅读<em class="icona icon-doushi"></em></h3>
			
					<div class="s-index-side">
					
                <div class="part weekly game-top10 cls">
                  <ul class="weekly-list cls">
				<?php $k = '0'; ?>
				<?php if(is_array($dataarea_list["pc_index_dushi"])): foreach($dataarea_list["pc_index_dushi"] as $key=>$v): $k = $k+1; ?>
<li>
<div class="app-show-title"><span class="num s-index-org"><?php echo ($k); ?>.</span><a href="<?php echo ($v["rewriteurl"]); ?>" ><?php echo ($v["title"]); ?></a></div>
<div class="app-show-block">
<a href="<?php echo ($v["rewriteurl"]); ?>" class="pic"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>"  /><span class="mask mask2"></span></a>
<dd><?php echo ($v["description"]); ?></dd>
</div>
</li><?php endforeach; endif; ?>
                 </ul>
               </div>
            </div>
          </div>

		  			<div class="t">
			<h3 class="lang">女生阅读<em class="icona icon-nvsheng"></em></h3>
			
					<div class="s-index-side">
					
                <div class="part weekly game-top10 cls">
                  <ul class="weekly-list cls">
				<?php $k = '0'; ?>
				<?php if(is_array($dataarea_list["pc_index_wangyou"])): foreach($dataarea_list["pc_index_wangyou"] as $key=>$v): $k = $k+1; ?>
<li>
<div class="app-show-title"><span class="num s-index-org"><?php echo ($k); ?>.</span><a href="<?php echo ($v["rewriteurl"]); ?>" ><?php echo ($v["title"]); ?></a></div>
<div class="app-show-block">
<a href="<?php echo ($v["rewriteurl"]); ?>" class="pic"><img <?php echo ($comset["src"]); ?>="<?php echo ($v["thumb"]); ?>" alt="<?php echo ($TDK["webname"]); ?> <?php echo ($v["title"]); ?>"  /><span class="mask mask2"></span></a>
<dd><?php echo ($v["description"]); ?></dd>
</div>
</li><?php endforeach; endif; ?>
                 </ul>
               </div>
            </div>
          </div>

			<div class="clear"></div>
		</div>
<!-- 小说第三板块结束 -->
<?php echo ($advcode["index_2"]["code"]); ?>
<!-- 最新更新开始 -->
		<div id="newscontent">
			<div class="l">
				<h2>
					最近更新列表
				</h2>
				<ul>
					<?php if(is_array($updatelist)): foreach($updatelist as $key=>$v): ?><li>
						<span class="s1">[<?php echo ($v['catename']); ?>]</span>
						<span class="s2"><a href="<?php echo ($v['rewriteurl']); ?>" title="点击阅读《<?php echo ($v['title']); ?>》"><?php echo ($v['title']); ?></a></span>
						<span class="s3"><p class="vip"> </p> <a class="chapter" href="<?php echo ($v['lastchapterurl']); ?>" title="<?php echo ($v['title']); echo ($v['lastchapter']); ?>阅读" target="_blank">更新到 <?php echo ($v['lastchapter']); ?> </a></span>
						<span class="s4"><a><?php echo ($v["author"]); ?></a></span>
						<span class="s5"><?php echo ($v['updatetime']); ?></span>
					</li><?php endforeach; endif; ?>
				</ul>
			</div>
			<div class="r">
				<h2>
					最新入库小说
				</h2>
				<ul>
					<?php $k = '0'; ?>
					<?php if(is_array($newestlist)): foreach($newestlist as $key=>$v): $k = $k+1; ?>
					<li>
						<span class="num<?php echo ($k); ?> numer"><?php echo ($k); ?></span>
						<span class="s2"><a class="chaptea"  href="<?php echo ($v['rewriteurl']); ?>" title="最新收录小说《<?php echo ($v['title']); ?>》"><?php echo ($v['title']); ?></a></span>
						<span class="s5"><a class="numce"><?php if($articledb['full'] == 0): ?>连载<?php else: ?>完本<?php endif; ?></a></span>
						
					</li><?php endforeach; endif; ?>
				</ul>
			</div>
			<div class="clear">
			</div>
		</div>
<!-- 最新入库小说结束 -->
		<?php echo ($advcode["index_3"]["code"]); ?>
	</div>
	<div id="firendlink">
		友情连接：<?php if(is_array($TDK["flink"])): foreach($TDK["flink"] as $key=>$v3): ?><a href="<?php echo ($v3['url']); ?>" target="_blank"><?php echo ($v3['name']); ?></a><?php endforeach; endif; ?>
	</div>
<!-- js -->
	<script src="//cdn.bootcss.com/jquery/2.1.4/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/header.js?v<?php echo ($version); ?>"></script>
	<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/paihuang.js"></script>
	
<div class="footer">
	<div class="footer_link"></div>
	<div class="footer_cont">
<p><?php echo ($TDK["gonggao1"]); ?></p>
<p><?php echo ($TDK["gonggao2"]); ?></p>
	</div>
</div>
<?php if($comset["src"] != 'src'): ?><script src="//cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>
<script>
$(function() {
	$('[rel-class=lazyload]').lazyload({effect: "fadeIn"});
});
</script><?php endif; ?>
<?php echo ($advcode["global_footer"]["code"]); ?>

</div>


</body>
</html>