<?php if (!defined('THINK_PATH')) exit(); if($index == 0): echo '<?'; ?>
xml version="1.0" encoding="utf-8"?>
<sitemapindex xmlns="<?php echo ($comset["http"]); ?>www.sitemaps.org/schemas/sitemap/0.9">
<?php if(is_array($sitemapdata['maplist'])): foreach($sitemapdata['maplist'] as $key=>$vo): ?><sitemap>
		<loc><![CDATA[<?php echo C('NOWHOST'); echo ($vo["listurl"]); ?>]]></loc>
		<lastmod><?php echo ($sitemapdata["mapinfo"]["dateline"]); ?></lastmod>
	</sitemap><?php endforeach; endif; ?>
</sitemapindex>
<?php elseif($index == 1): ?>
<?php echo '<?'; ?>
xml version="1.0" encoding="utf-8"?>
<urlset xmlns="<?php echo ($comset["http"]); ?>www.sitemaps.org/schemas/sitemap/0.9">
	<url>
		<loc><?php echo ($sitemapdata["mapinfo"]["weburl"]); ?></loc>
		<lastmod><?php echo ($sitemapdata["mapinfo"]["dateline"]); ?></lastmod>
		<changefreq>daily</changefreq>
		<priority>1.0</priority>
	</url>
	<?php if(is_array($sitemapdata["category"])): foreach($sitemapdata["category"] as $key=>$vo): ?><url>
		<loc><?php echo ($vo["url"]); ?></loc>
		<lastmod><?php echo ($sitemapdata["mapinfo"]["dateline"]); ?></lastmod>
		<changefreq>daily</changefreq>
		<priority>0.3</priority>
	</url><?php endforeach; endif; ?>
	<?php if(is_array($sitemapdata["taginfo"])): foreach($sitemapdata["taginfo"] as $key=>$vo): ?><url>
		<loc><?php echo ($vo["rewriteurl"]); ?></loc>
		<lastmod><?php echo ($sitemapdata["mapinfo"]["dateline"]); ?></lastmod>
		<changefreq>daily</changefreq>
		<priority>0.3</priority>
	</url><?php endforeach; endif; ?>
</urlset>
<?php else: ?>
<?php echo '<?'; ?>
xml version="1.0" encoding="utf-8"?>
<urlset xmlns="<?php echo ($comset["http"]); ?>www.sitemaps.org/schemas/sitemap/0.9">
	<url>
		<loc><?php echo ($sitemapdata["mapinfo"]["weburl"]); ?></loc>
		<lastmod><?php echo ($sitemapdata["mapinfo"]["dateline"]); ?></lastmod>
		<changefreq>daily</changefreq>
		<priority>1.0</priority>
	</url>
	<?php if(is_array($sitemapdata["mapinfo"]["maplist"])): foreach($sitemapdata["mapinfo"]["maplist"] as $key=>$vo): ?><url>
		<loc><?php echo ($vo["rewriteurl"]); ?></loc>
		<lastmod><?php echo ($sitemapdata["mapinfo"]["dateline"]); ?></lastmod>
		<changefreq>daily</changefreq>
		<priority>0.8</priority>
	</url><?php endforeach; endif; ?>
</urlset><?php endif; ?>