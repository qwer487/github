<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<meta http-equiv="Cache-Control" content="no-transform" />
	<title><?php echo ($TDK["title"]); ?></title>
	<meta name="keywords" content="<?php echo ($TDK["keyword"]); ?>" />
	<meta name="description" content="<?php echo ($TDK["description"]); ?>" />
	<link rel="canonical" href="<?php echo ($TDK["canonicalurl"]); ?>"/>
	<meta name="applicable-device" content="pc">
	<meta http-equiv="mobile-agent" content="format=html5; url=<?php echo ($TDK["canonicalurl_m"]); ?>">
	<link rel="stylesheet" href="/Public/<?php echo ($theme); ?>/css/style.css?v<?php echo ($version); ?>" />
	<script src="//cdn.bootcss.com/jquery/2.1.4/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/header.js?v<?php echo ($version); ?>"></script>
	<script>var znsid = '<?php echo ($comset["znsid"]); ?>';</script>
</head>
<body>
<div id="wrapper">
	<div class="header">
	<div class="header_logo">
		<a href="<?php echo ($TDK["weburl"]); ?>" title="<?php echo ($TDK["webname"]); ?>"><?php echo ($TDK["webname"]); ?></a>
	</div>
			<div class="inner s96 cf">
				<form action="<?php echo U('/home/search');?>" method="post">
				<input type="hidden" name="action" value="search">
				<input name="q" placeholder="可以搜索 作者 书名" type="text" class="searchinput" required><button class="searchbtn" type="submit">搜索</button>
				</form>
			</div>
			<div class="inner s97 cf">
			<div class="daos1">
				<a href="<?php echo ($catelist["all"]); ?>">全部分类</a>
				<a href="<?php echo U('/quanben');?>">完结小说</a>
				<a href="<?php echo ($TDK["canonicalurl_m"]); ?>">手机版</a>
			</div>
			</div>
</div>
<div class="s92">
<div class="nav">
	<ul>
		<li><a href="<?php echo ($TDK["weburl"]); ?>" title="<?php echo ($TDK["webname"]); ?>">书城首页</a></li>
				<?php if(is_array($category)): foreach($category as $key=>$vo): ?><li class="tou2" ><a href="<?php echo ($vo['url']); ?>"><?php echo ($vo['name']); ?></a></li><?php endforeach; endif; ?>
		<li><a href="<?php echo ($catelist["top"]); ?>">排行榜单</a></li>
		<li><a href="<?php echo U('/home/index/bookcase');?>">书架</a></li>
	</ul>
</div>
</div>
		<div class="pais91">
			   <div class="pais92">
				  <h2>
				  <?php echo ($TDK["webname"]); ?>周榜
				  </h2>
				  <ul>
					<?php $k = '0'; ?>
					<?php if(is_array($dataarea_list["pc_top_week"])): foreach($dataarea_list["pc_top_week"] as $key=>$v): $k = $k+1; ?>
					<li>
						<span class="num<?php echo ($k); ?> numer"><?php echo ($k); ?></span>
						<span class="s2"><a class="chaptea"  href="<?php echo ($v['rewriteurl']); ?>" title="最新收录小说《<?php echo ($v['title']); ?>》"><?php echo ($v['title']); ?></a></span>
						<span class="pais93"><?php echo ($v["author"]); ?></span>
						<span class="s5"><a class="numce"><?php if($articledb['full'] == 0): ?>连载<?php else: ?>完本<?php endif; ?></a></span>
						<span class="numce"><?php echo ($v["weekviews"]); ?>热度</span>
						
					</li><?php endforeach; endif; ?>
				 </ul>
			</div>
			
			<div class="pais92">
				  <h2>
				  <?php echo ($TDK["webname"]); ?>月榜
				  </h2>
				  <ul>
					<?php $k = '0'; ?>
					<?php if(is_array($dataarea_list["pc_top_month"])): foreach($dataarea_list["pc_top_month"] as $key=>$v): $k = $k+1; ?>
					<li>
						<span class="num<?php echo ($k); ?> numer"><?php echo ($k); ?></span>
						<span class="s2"><a class="chaptea"  href="<?php echo ($v['rewriteurl']); ?>" title="最新收录小说《<?php echo ($v['title']); ?>》"><?php echo ($v['title']); ?></a></span>
						<span class="pais93"><?php echo ($v["author"]); ?></span>
						<span class="s5"><a class="numce"><?php if($articledb['full'] == 0): ?>连载<?php else: ?>完本<?php endif; ?></a></span>
						<span class="numce"><?php echo ($v["monthviews"]); ?>热度</span>
					</li><?php endforeach; endif; ?>
				 </ul>
			</div>

			<div class="pais92">
				  <h2>
				  <?php echo ($TDK["webname"]); ?>总榜
				  </h2>
				  <ul>
					<?php $k = '0'; ?>
					<?php if(is_array($dataarea_list["pc_top_all"])): foreach($dataarea_list["pc_top_all"] as $key=>$v): $k = $k+1; ?>
					<li>
						<span class="num<?php echo ($k); ?> numer"><?php echo ($k); ?></span>
						<span class="s2"><a class="chaptea"  href="<?php echo ($v['rewriteurl']); ?>" title="最新收录小说《<?php echo ($v['title']); ?>》"><?php echo ($v['title']); ?></a></span>
						<span class="pais93"><?php echo ($v["author"]); ?></span>
						<span class="s5"><a class="numce"><?php if($articledb['full'] == 0): ?>连载<?php else: ?>完本<?php endif; ?></a></span>
						<span class="numce"><?php echo ($v["views"]); ?>热度</span>
					</li><?php endforeach; endif; ?>
				 </ul>
			</div>

		</div>
	<div class="footer">
	<div class="footer_link"></div>
	<div class="footer_cont">
		<script>footer();</script><?php echo ($statcode); ?>
	</div>
</div>
<?php if($comset["src"] != 'src'): ?><script src="//cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>
<script>
$(function() {
	$('[rel-class=lazyload]').lazyload({effect: "fadeIn"});
});
</script><?php endif; ?>
<?php echo ($advcode["global_footer"]["code"]); ?>
</div>
</body>
</html>