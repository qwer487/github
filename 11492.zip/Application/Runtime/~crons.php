<?php
return array (
  'cron_pick' => 
  array (
    0 => 'autopick',
    1 => 1800,
    2 => 1570911091,
  ),
  'cron_dataarea_update' => 
  array (
    0 => 'dataarea_update',
    1 => 1800,
    2 => 1570911091,
  ),
);
?>